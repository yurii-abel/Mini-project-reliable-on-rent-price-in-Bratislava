#!/usr/bin/python3

from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.pyplot as plt
import textwrap

# Tento skript vytvorí jednoduchý PDF report zo súboru report.md.

vstup = "report.md"
vystup = "report.pdf"

with open(vstup, "r", encoding="utf-8") as f:
    text = f.read()

riadky = []

for line in text.splitlines():
    if line.startswith("# "):
        riadky.append(line.replace("# ", "").upper())
        riadky.append("")
    elif line.startswith("## "):
        riadky.append("")
        riadky.append(line.replace("## ", ""))
        riadky.append("")
    elif line.startswith("- "):
        riadky.append(line)
    else:
        if line == "":
            riadky.append("")
        else:
            riadky.extend(textwrap.wrap(line, width=85))

strany = []

for i in range(0, len(riadky), 42):
    strany.append(riadky[i:i+42])

with PdfPages(vystup) as pdf:
    for strana in strany:
        fig = plt.figure(figsize=(8.27, 11.69))
        plt.axis("off")

        y = 0.96

        for riadok in strana:
            plt.figtext(0.08, y, riadok, fontsize=10, ha="left", va="top")
            y -= 0.022

        pdf.savefig(fig)
        plt.close()

print("PDF bol vytvoreny:", vystup)
