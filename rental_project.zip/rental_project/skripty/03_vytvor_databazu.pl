#!/usr/bin/perl
use strict;
use warnings;
use utf8;

# Tento skript vytvorí SQLite databázu
# a vloží do nej pôvodné aj vyčistené údaje.

binmode(STDOUT, ":encoding(UTF-8)");

my $databaza = "databaza/prenajom_bytov.sqlite";
my $schema = "sql/vytvor_tabulky.sql";

system("sqlite3 $databaza < $schema") == 0
    or die "Nepodarilo sa vytvorit databazu.\n";

sub uprav_text {
    my ($text) = @_;
    $text = "" unless defined $text;
    $text =~ s/'/''/g;
    return $text;
}

# Vloženie pôvodných údajov
open(my $povodne, "<:encoding(UTF-8)", "udaje/povodne/ponuky_povodne.tsv")
    or die "Nepodarilo sa otvorit povodne udaje: $!";

my $hlavicka1 = <$povodne>;

while (my $riadok = <$povodne>) {
    chomp $riadok;

    my ($nazov, $cena_text, $rozloha_text, $izby_text, $lokalita_text, $odkaz)
        = split /\t/, $riadok;

    $nazov = uprav_text($nazov);
    $cena_text = uprav_text($cena_text);
    $rozloha_text = uprav_text($rozloha_text);
    $izby_text = uprav_text($izby_text);
    $lokalita_text = uprav_text($lokalita_text);
    $odkaz = uprav_text($odkaz);

    my $sql = "
        INSERT OR IGNORE INTO povodne_ponuky
        (nazov, cena_text, rozloha_text, izby_text, lokalita_text, odkaz, datum_ziskania)
        VALUES
        ('$nazov', '$cena_text', '$rozloha_text', '$izby_text', '$lokalita_text', '$odkaz', date('now'));
    ";

    system("sqlite3 $databaza \"$sql\"");
}

close $povodne;

# Vloženie vyčistených údajov
open(my $spracovane, "<:encoding(UTF-8)", "udaje/spracovane/ponuky_spracovane.tsv")
    or die "Nepodarilo sa otvorit spracovane udaje: $!";

my $hlavicka2 = <$spracovane>;
my $id = 1;

while (my $riadok = <$spracovane>) {
    chomp $riadok;

    my ($nazov, $cena_eur, $rozloha_m2, $pocet_izieb, $mestska_cast, $cena_za_m2, $poznamka_k_cene, $odkaz)
        = split /\t/, $riadok;

    $nazov = uprav_text($nazov);
    $mestska_cast = uprav_text($mestska_cast);
    $poznamka_k_cene = uprav_text($poznamka_k_cene);
    $odkaz = uprav_text($odkaz);

    my $sql = "
        INSERT INTO spracovane_ponuky
        (id, nazov, cena_eur, rozloha_m2, pocet_izieb, mestska_cast, cena_za_m2, poznamka_k_cene, odkaz)
        VALUES
        ($id, '$nazov', $cena_eur, $rozloha_m2, $pocet_izieb, '$mestska_cast', $cena_za_m2, '$poznamka_k_cene', '$odkaz');
    ";

    system("sqlite3 $databaza \"$sql\"");
    $id++;
}

close $spracovane;

# Vytvorenie súhrnu podľa mestských častí
my $sql_suhrn = "
    INSERT INTO suhrn_podla_casti
    SELECT
        mestska_cast,
        COUNT(*) AS pocet_ponuk,
        ROUND(AVG(cena_eur), 2) AS priemerna_cena,
        MIN(cena_eur) AS najnizsia_cena,
        MAX(cena_eur) AS najvyssia_cena,
        ROUND(AVG(rozloha_m2), 2) AS priemerna_rozloha,
        ROUND(AVG(cena_za_m2), 2) AS priemerna_cena_za_m2
    FROM spracovane_ponuky
    GROUP BY mestska_cast;
";

system("sqlite3 $databaza \"$sql_suhrn\"");

print "Databaza bola vytvorena: $databaza\n";
