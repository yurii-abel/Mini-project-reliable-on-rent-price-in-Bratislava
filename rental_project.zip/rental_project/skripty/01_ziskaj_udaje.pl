#!/usr/bin/perl
use strict;
use warnings;
use utf8;
use Encode qw(decode);

# Skript stiahne niekoľko stránok z portálu TopReality
# a vytvorí tabuľku pôvodných ponúk vo formáte TSV.

binmode(STDOUT, ":encoding(UTF-8)");

my $vystupny_subor = "udaje/povodne/ponuky_povodne.tsv";
my $pocet_stran = 3;

open(my $vystup, ">:encoding(UTF-8)", $vystupny_subor)
    or die "Nepodarilo sa vytvorit subor $vystupny_subor: $!";

print $vystup "nazov\tcena_text\trozloha_text\tizby_text\tlokalita_text\todkaz\n";

my %videne_odkazy;
my $pocet_ponuk = 0;

sub vycisti_text {
    my ($text) = @_;
    $text = "" unless defined $text;

    $text =~ s/<[^>]+>/ /g;
    $text =~ s/&amp;/&/g;
    $text =~ s/&quot;/"/g;
    $text =~ s/&#039;/'/g;
    $text =~ s/&nbsp;/ /g;
    $text =~ s/\s+/ /g;
    $text =~ s/^\s+|\s+$//g;

    return $text;
}

for my $strana (0 .. $pocet_stran - 1) {
    my $url = "https://www.topreality.sk/byty-prenajom-t100-$strana.html";

    print "Sťahujem stránku: $url\n";

    my $html_bytes = `curl -L -s "$url"`;
    next if $html_bytes eq "";

    my $html = decode("UTF-8", $html_bytes);

    my @bloky = split /<div class="col-lg-12 col-md-6 col-12 item-col/, $html;

    foreach my $blok (@bloky) {
        next unless $blok =~ /data-ga4-container-item_name=/;

        my ($nazov) = $blok =~ /data-ga4-container-item_name="([^"]+)"/;
        my ($cena) = $blok =~ /data-ga4-container-price="([^"]+)"/;
        my ($izby) = $blok =~ /data-ga4-container-item_category2="([^"]+)"/;
        my ($lokalita) = $blok =~ /data-ga4-container-item_category3="([^"]+)"/;
        my ($odkaz) = $blok =~ /<a href="(https:\/\/www\.topreality\.sk\/[^"]+)"/;

        next unless defined $nazov;
        next unless defined $cena;
        next unless defined $izby;
        next unless defined $lokalita;
        next unless defined $odkaz;

        next if $videne_odkazy{$odkaz};
        $videne_odkazy{$odkaz} = 1;

        my $rozloha = "";

        if ($blok =~ /([0-9]+(?:[,.][0-9]+)?)\s*m(?:2|²)/i) {
            $rozloha = "$1 m2";
        } elsif ($blok =~ /([0-9]+(?:[,.][0-9]+)?)\s*m\s*<sup>\s*2\s*<\/sup>/i) {
            $rozloha = "$1 m2";
        }

        $nazov = vycisti_text($nazov);
        $cena = vycisti_text($cena) . " EUR";
        $izby = vycisti_text($izby);
        $lokalita = vycisti_text($lokalita);

        if ($lokalita =~ /^Bratislava-(.+)$/) {
            $lokalita = "Bratislava - $1";
        }

        next if $rozloha eq "";

        print $vystup join(
            "\t",
            $nazov,
            $cena,
            $rozloha,
            $izby,
            $lokalita,
            $odkaz
        ), "\n";

        $pocet_ponuk++;
    }

    sleep 1;
}

close $vystup;

print "Hotovo. Počet získaných ponúk: $pocet_ponuk\n";
print "Údaje boli uložené do súboru $vystupny_subor\n";
