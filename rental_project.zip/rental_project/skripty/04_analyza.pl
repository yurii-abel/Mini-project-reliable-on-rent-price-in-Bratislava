#!/usr/bin/perl
use strict;
use warnings;
use utf8;

# Tento skript uloží hlavné výsledky analýzy do CSV súborov.

binmode(STDOUT, ":encoding(UTF-8)");

my $databaza = "databaza/prenajom_bytov.sqlite";

print "Spúšťam analýzu údajov...\n";

# Súhrn podľa mestských častí
system("sqlite3 -header -csv $databaza \"SELECT * FROM suhrn_podla_casti ORDER BY priemerna_cena DESC;\" > vysledky/suhrn_podla_casti.csv");

# Najlacnejšie ponuky podľa celkovej ceny
system("sqlite3 -header -csv $databaza \"SELECT nazov, mestska_cast, pocet_izieb, rozloha_m2, cena_eur, cena_za_m2, poznamka_k_cene FROM spracovane_ponuky ORDER BY cena_eur ASC LIMIT 10;\" > vysledky/najlacnejsie_ponuky.csv");

# Najvýhodnejšie ponuky v Starom Meste podľa ceny za m2
system("sqlite3 -header -csv $databaza \"SELECT nazov, pocet_izieb, rozloha_m2, cena_eur, cena_za_m2, poznamka_k_cene FROM spracovane_ponuky WHERE mestska_cast = 'Staré Mesto' ORDER BY cena_za_m2 ASC LIMIT 10;\" > vysledky/najlepsie_ponuky_stare_mesto.csv");

# Súhrn podľa počtu izieb
system("sqlite3 -header -csv $databaza \"SELECT pocet_izieb, COUNT(*) AS pocet_ponuk, ROUND(AVG(cena_eur), 2) AS priemerna_cena, ROUND(AVG(cena_za_m2), 2) AS priemerna_cena_za_m2 FROM spracovane_ponuky GROUP BY pocet_izieb ORDER BY pocet_izieb;\" > vysledky/suhrn_podla_izieb.csv");

# Kontrola poznámky k cene
system("sqlite3 -header -csv $databaza \"SELECT poznamka_k_cene, COUNT(*) AS pocet_ponuk FROM spracovane_ponuky GROUP BY poznamka_k_cene;\" > vysledky/poznamka_k_cene.csv");

print "Analýza bola dokončená. Výsledky sú v priečinku vysledky.\n";
