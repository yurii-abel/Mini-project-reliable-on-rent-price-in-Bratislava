#!/usr/bin/perl
use strict;
use warnings;
use utf8;

# Tento skript vyčistí údaje získané z realitného portálu.
# Z textu vyberie cenu, rozlohu, počet izieb a mestskú časť.

binmode(STDOUT, ":encoding(UTF-8)");

my $vstup = "udaje/povodne/ponuky_povodne.tsv";
my $vystup = "udaje/spracovane/ponuky_spracovane.tsv";

open(my $in, "<:encoding(UTF-8)", $vstup)
    or die "Nepodarilo sa otvorit vstupny subor: $!";

open(my $out, ">:encoding(UTF-8)", $vystup)
    or die "Nepodarilo sa vytvorit vystupny subor: $!";

my $hlavicka = <$in>;

print $out "nazov\tcena_eur\trozloha_m2\tpocet_izieb\tmestska_cast\tcena_za_m2\tpoznamka_k_cene\todkaz\n";

while (my $riadok = <$in>) {
    chomp $riadok;

    my ($nazov, $cena_text, $rozloha_text, $izby_text, $lokalita_text, $odkaz)
        = split /\t/, $riadok;

    # Nechávam iba ponuky z Bratislavy.
    next unless $lokalita_text =~ /^Bratislava\s*-\s*/;

    my $cena = "";
    if ($cena_text =~ /([0-9]+(?:[.,][0-9]+)?)/) {
        $cena = $1;
        $cena =~ s/,/./;
    }

    my $rozloha = "";
    if ($rozloha_text =~ /([0-9]+(?:[.,][0-9]+)?)/) {
        $rozloha = $1;
        $rozloha =~ s/,/./;
    }

    my $pocet_izieb = "";
    if ($izby_text =~ /([0-9]+)/) {
        $pocet_izieb = $1;
    }

    my $mestska_cast = $lokalita_text;
    $mestska_cast =~ s/^Bratislava\s*-\s*//;

    my $poznamka_k_cene = "nezname";
    my $text = lc($nazov . " " . $cena_text);

    if ($text =~ /energi/) {
        $poznamka_k_cene = "spomina energie";
    }

    next if $cena eq "";
    next if $rozloha eq "";
    next if $rozloha == 0;

    my $cena_za_m2 = $cena / $rozloha;

    print $out join(
        "\t",
        $nazov,
        $cena,
        $rozloha,
        $pocet_izieb,
        $mestska_cast,
        sprintf("%.2f", $cena_za_m2),
        $poznamka_k_cene,
        $odkaz
    ), "\n";
}

close $in;
close $out;

print "Vyčistené údaje boli uložené do súboru $vystup\n";
