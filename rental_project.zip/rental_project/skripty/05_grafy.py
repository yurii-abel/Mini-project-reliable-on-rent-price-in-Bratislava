#!/usr/bin/python3

import sqlite3
import matplotlib.pyplot as plt

# Tento skript vytvorí jednoduché grafy z SQLite databázy.

databaza = "databaza/prenajom_bytov.sqlite"

conn = sqlite3.connect(databaza)
cursor = conn.cursor()

# 1. Priemerná cena podľa mestských častí
cursor.execute("""
    SELECT mestska_cast, priemerna_cena
    FROM suhrn_podla_casti
    ORDER BY priemerna_cena DESC
""")

data = cursor.fetchall()
casti = [riadok[0] for riadok in data]
ceny = [riadok[1] for riadok in data]

plt.figure(figsize=(10, 5))
plt.bar(casti, ceny)
plt.title("Priemerná cena prenájmu podľa mestských častí")
plt.xlabel("Mestská časť")
plt.ylabel("Priemerná cena v EUR")
plt.xticks(rotation=30, ha="right")
plt.tight_layout()
plt.savefig("grafy/priemerna_cena_podla_casti.png")
plt.close()

# 2. Priemerná cena za m2 podľa mestských častí
cursor.execute("""
    SELECT mestska_cast, priemerna_cena_za_m2
    FROM suhrn_podla_casti
    ORDER BY priemerna_cena_za_m2 DESC
""")

data = cursor.fetchall()
casti = [riadok[0] for riadok in data]
ceny_m2 = [riadok[1] for riadok in data]

plt.figure(figsize=(10, 5))
plt.bar(casti, ceny_m2)
plt.title("Priemerná cena za m² podľa mestských častí")
plt.xlabel("Mestská časť")
plt.ylabel("Cena za m² v EUR")
plt.xticks(rotation=30, ha="right")
plt.tight_layout()
plt.savefig("grafy/cena_za_m2_podla_casti.png")
plt.close()

# 3. Vzťah medzi rozlohou a cenou
cursor.execute("""
    SELECT rozloha_m2, cena_eur
    FROM spracovane_ponuky
""")

data = cursor.fetchall()
rozlohy = [riadok[0] for riadok in data]
ceny = [riadok[1] for riadok in data]

plt.figure(figsize=(8, 5))
plt.scatter(rozlohy, ceny)
plt.title("Vzťah medzi rozlohou a cenou prenájmu")
plt.xlabel("Rozloha v m²")
plt.ylabel("Cena v EUR")
plt.tight_layout()
plt.savefig("grafy/cena_a_rozloha.png")
plt.close()

# 4. Počet ponúk podľa mestských častí
cursor.execute("""
    SELECT mestska_cast, pocet_ponuk
    FROM suhrn_podla_casti
    ORDER BY pocet_ponuk DESC
""")

data = cursor.fetchall()
casti = [riadok[0] for riadok in data]
pocty = [riadok[1] for riadok in data]

plt.figure(figsize=(10, 5))
plt.bar(casti, pocty)
plt.title("Počet ponúk podľa mestských častí")
plt.xlabel("Mestská časť")
plt.ylabel("Počet ponúk")
plt.xticks(rotation=30, ha="right")
plt.tight_layout()
plt.savefig("grafy/pocet_ponuk_podla_casti.png")
plt.close()

conn.close()

print("Grafy boli vytvorené v priečinku grafy.")
