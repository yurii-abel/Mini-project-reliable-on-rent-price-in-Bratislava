#!/usr/bin/perl
use strict;
use warnings;
use utf8;

# Hlavný skript projektu.
# Spustí všetky kroky v správnom poradí.

binmode(STDOUT, ":encoding(UTF-8)");

print "Spúšťam projekt: Analýza prenájmu bytov v Bratislave\n\n";

print "1. Získanie údajov z webu...\n";
system("perl skripty/01_ziskaj_udaje.pl") == 0
    or die "Chyba pri získavaní údajov.\n";

print "\n2. Čistenie údajov...\n";
system("perl skripty/02_vycisti_udaje.pl") == 0
    or die "Chyba pri čistení údajov.\n";

print "\n3. Vytvorenie databázy...\n";
system("perl skripty/03_vytvor_databazu.pl") == 0
    or die "Chyba pri vytváraní databázy.\n";

print "\n4. SQL analýza...\n";
system("perl skripty/04_analyza.pl") == 0
    or die "Chyba pri analýze údajov.\n";

print "\n5. Vytvorenie grafov...\n";
system("python3 skripty/05_grafy.py") == 0
    or die "Chyba pri vytváraní grafov.\n";

print "\nKontrolný výpis podľa mestských častí:\n";
system("sqlite3 -header -column databaza/prenajom_bytov.sqlite \"SELECT * FROM suhrn_podla_casti ORDER BY priemerna_cena DESC;\"");

print "\nProjekt bol úspešne dokončený.\n";
print "Databáza: databaza/prenajom_bytov.sqlite\n";
print "Výsledky: vysledky/\n";
print "Grafy: grafy/\n";
