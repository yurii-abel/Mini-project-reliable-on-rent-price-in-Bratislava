# Analýza cien prenájmu bytov v Bratislave

## 1. Úvod

V tomto projekte som sa venoval analýze cien prenájmu bytov v Bratislave. Cieľom bolo získať údaje z realitného portálu, upraviť ich do použiteľnej formy, uložiť ich do databázy a potom z nich vytvoriť jednoduchú analýzu.

Zaujímalo ma hlavne to, ako sa líšia ceny prenájmov v jednotlivých mestských častiach Bratislavy a aká je cena za meter štvorcový.

## 2. Zdroj údajov

Údaje som získal z realitného portálu TopReality. Použil som ponuky bytov na prenájom.

Zdroj údajov:

https://www.topreality.sk/byty-prenajom-t100-0.html

Zo stránky som získal názov ponuky, cenu, rozlohu, počet izieb, lokalitu a odkaz na inzerát. V projekte som nechal iba ponuky, ktoré sa nachádzajú v Bratislave.

## 3. Použité nástroje

Na projekt som použil tieto nástroje:

- Perl 5,
- SQLite,
- Python 3,
- matplotlib,
- príkazový riadok v Linuxe.

Perl som použil na získanie a čistenie údajov. SQLite som použil na uloženie údajov a SQL analýzu. Python som použil na vytvorenie grafov.

## 4. Spracovanie údajov

Najprv som pomocou skriptu získal údaje z webovej stránky. Tieto údaje som uložil do súboru `ponuky_povodne.tsv`.

Potom som údaje vyčistil. Z textu som vybral cenu, rozlohu, počet izieb a mestskú časť. Z ceny a rozlohy som vypočítal aj cenu za meter štvorcový.

Použil som aj jednoduchú poznámku k cene. Ak sa v texte ponuky spomínajú energie, program to vie označiť. V mojich získaných dátach sa však energie jasne nespomínali, preto majú ponuky hodnotu `nezname`.

## 5. Databáza

Vyčistené údaje som uložil do SQLite databázy s názvom `prenajom_bytov.sqlite`.

Databáza obsahuje tri tabuľky:

- `povodne_ponuky` – pôvodné údaje z webu,
- `spracovane_ponuky` – vyčistené údaje,
- `suhrn_podla_casti` – súhrn podľa mestských častí.

V tabuľke `spracovane_ponuky` sú uložené napríklad cena, rozloha, počet izieb, mestská časť a cena za meter štvorcový.

## 6. Analýza

V projekte som vytvoril jednoduchú analýzu cien prenájmov. Pozeral som sa hlavne na:

- priemernú cenu podľa mestských častí,
- priemernú cenu za meter štvorcový,
- počet ponúk v mestských častiach,
- najlacnejšie ponuky,
- ponuky v Starom Meste.

Výsledky analýzy sú uložené v priečinku `vysledky/`.

## 7. Grafy

Na lepšie zobrazenie výsledkov som vytvoril štyri grafy:

- priemerná cena podľa mestských častí,
- cena za meter štvorcový podľa mestských častí,
- vzťah medzi rozlohou a cenou,
- počet ponúk podľa mestských častí.

Grafy sú uložené v priečinku `grafy/`.

## 8. Výsledky

Podľa získaných údajov bola najvyššia priemerná cena prenájmu v Starom Meste. Staré Mesto malo aj vyššiu cenu za meter štvorcový.

Nižšie ceny boli napríklad v Ružinove, Karlovej Vsi alebo Devínskej Novej Vsi. Treba však povedať, že počet ponúk nebol veľmi veľký, preto výsledky beriem skôr ako ukážku analýzy než ako presnú štatistiku celého trhu.

## 9. Poznámka k energiám

Pri prenájmoch je problém, že energie nie sú vždy uvedené rovnakým spôsobom. Niekedy môžu byť v cene, niekedy sa platia zvlášť a niekedy to v inzeráte nie je jasné.

Preto som v projekte nepočítal presné celkové mesačné náklady. Pracoval som s cenou, ktorá bola uvedená pri ponuke. Toto je jedno z obmedzení projektu.

## 10. Záver

Projekt ukazuje jednoduchý postup práce s dátami. Najprv som získal údaje z webu, potom som ich vyčistil, uložil do databázy, analyzoval pomocou SQL a nakoniec som vytvoril grafy.

Projekt by sa dal zlepšiť tak, že by sa získalo viac ponúk alebo by sa podrobnejšie spracovali energie a ďalšie poplatky.
