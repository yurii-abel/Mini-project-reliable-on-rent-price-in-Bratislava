DROP TABLE IF EXISTS povodne_ponuky;
DROP TABLE IF EXISTS spracovane_ponuky;
DROP TABLE IF EXISTS suhrn_podla_casti;

CREATE TABLE povodne_ponuky (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nazov TEXT,
    cena_text TEXT,
    rozloha_text TEXT,
    izby_text TEXT,
    lokalita_text TEXT,
    odkaz TEXT UNIQUE,
    datum_ziskania TEXT
);

CREATE TABLE spracovane_ponuky (
    id INTEGER PRIMARY KEY,
    nazov TEXT,
    cena_eur REAL,
    rozloha_m2 REAL,
    pocet_izieb REAL,
    mestska_cast TEXT,
    cena_za_m2 REAL,
    poznamka_k_cene TEXT,
    odkaz TEXT
);

CREATE TABLE suhrn_podla_casti (
    mestska_cast TEXT PRIMARY KEY,
    pocet_ponuk INTEGER,
    priemerna_cena REAL,
    najnizsia_cena REAL,
    najvyssia_cena REAL,
    priemerna_rozloha REAL,
    priemerna_cena_za_m2 REAL
);
